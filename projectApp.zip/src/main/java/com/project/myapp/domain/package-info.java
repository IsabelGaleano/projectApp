/**
 * JPA domain objects.
 */
package com.project.myapp.domain;
