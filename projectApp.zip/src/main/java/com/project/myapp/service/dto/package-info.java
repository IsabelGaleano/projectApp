/**
 * Data Transfer Objects.
 */
package com.project.myapp.service.dto;
