/**
 * Service layer beans.
 */
package com.project.myapp.service;
