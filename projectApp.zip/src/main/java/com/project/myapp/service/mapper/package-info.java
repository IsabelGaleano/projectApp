/**
 * MapStruct mappers for mapping domain objects and Data Transfer Objects.
 */
package com.project.myapp.service.mapper;
