/**
 * Data Access Objects used by WebSocket services.
 */
package com.project.myapp.web.websocket.dto;
