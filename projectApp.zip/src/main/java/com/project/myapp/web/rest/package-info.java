/**
 * Spring MVC REST controllers.
 */
package com.project.myapp.web.rest;
