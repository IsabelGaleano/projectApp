/**
 * View Models used by Spring MVC REST controllers.
 */
package com.project.myapp.web.rest.vm;
