/**
 * Spring Security configuration.
 */
package com.project.myapp.security;
