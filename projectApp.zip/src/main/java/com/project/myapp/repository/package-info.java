/**
 * Spring Data JPA repositories.
 */
package com.project.myapp.repository;
